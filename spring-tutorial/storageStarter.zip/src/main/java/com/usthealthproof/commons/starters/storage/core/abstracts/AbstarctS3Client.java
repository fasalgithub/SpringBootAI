package com.usthealthproof.commons.starters.storage.core.abstracts;

public abstract class AbstarctS3Client {

   /* private AmazonS3Client amazonS3Client;

    public AmazonS3Client getAmazonS3Client() {
        if(null == amazonS3Client) {
            amazonS3Client = (AmazonS3Client) AmazonS3ClientBuilder.standard()
                    .withCredentials(new DefaultAWSCredentialsProviderChain())
                    .build();
        }
        return amazonS3Client;
    }*/
}
