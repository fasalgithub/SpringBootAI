package com.usthealthproof.commons.starters.storage.core.abstracts;

public interface Listener {
}
